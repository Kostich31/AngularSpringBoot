import { NgModule } from '@angular/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { NewUserComponent } from './component/new-user/new-user.component.js';
import { UserComponent } from './component/user/user.component.js';

export const routes: Routes = [
  { path: 'users', component: UserComponent },
  { path: 'user/new', component: NewUserComponent },
  { path: '', redirectTo: 'users', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes), ReactiveFormsModule, FormsModule],
  exports: [RouterModule],
})
export class AppRoutingModule {}
