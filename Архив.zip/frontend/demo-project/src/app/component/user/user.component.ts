import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { RouterModule } from '@angular/router';
import { MaterialModule } from '../../material.module.js';
import { User } from '../../models/User.js';
import { UserService } from '../../service/user.service.js';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrl: './user.component.css',
  standalone: true,
  imports: [CommonModule, RouterModule, MaterialModule],
})
export class UserComponent implements OnInit {
  isUsersLoaded = false;
  users: User[] = [];
  constructor(private userService: UserService) {}

  ngOnInit(): void {
    this.userService.getAllUsers().subscribe((data) => {
      console.log(data);
      this.users = data;
      this.isUsersLoaded = true;
    });
  }
}
