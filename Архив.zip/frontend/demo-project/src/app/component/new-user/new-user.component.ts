import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  FormsModule,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { MaterialModule } from '../../material.module.js';
import { UserService } from '../../service/user.service.js';

@Component({
  selector: 'app-new-user',
  standalone: true,
  templateUrl: './new-user.component.html',
  styleUrl: './new-user.component.css',
  imports: [
    ReactiveFormsModule,
    FormsModule,
    CommonModule,
    RouterModule,
    MaterialModule,
  ],
})
export class NewUserComponent implements OnInit {
  public userForm!: FormGroup;
  constructor(
    private router: Router,
    private fb: FormBuilder,
    private userService: UserService
  ) {}
  ngOnInit(): void {
    console.log('render');
    this.userForm = this.createLoginForm();
  }
  createLoginForm(): FormGroup {
    return this.fb.group({
      firstname: ['', Validators.compose([Validators.required])],
      lastname: ['', Validators.compose([Validators.required])],
      username: ['', Validators.compose([Validators.required])],
      email: ['', Validators.compose([Validators.required])],
      bio: ['', Validators.compose([Validators.required])],
      password: ['', Validators.compose([Validators.required])],
    });
  }
  submit(): void {
    if (this.userForm) {
      console.log(this.userForm.value.username);
      this.userService
        .createUser({
          firstname: this.userForm.value.firstname,
          lastname: this.userForm.value.lastname,
          username: this.userForm.value.username,
          email: this.userForm.value.email,
          bio: this.userForm.value.bio,
          password: this.userForm.value.password,
        })
        .subscribe((data) => {
          this.router.navigate(['/users']);
        });
    }
  }
}
