import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from '../models/User.js';

const USER_API = 'http://localhost:8080/api/user/';
@Injectable({
  providedIn: 'root',
})
export class UserService {
  constructor(private http: HttpClient) {}
  createUser(user: User): Observable<any> {
    return this.http.post(USER_API + 'create', user);
  }
  getAllUsers(): Observable<any> {
    return this.http.get(USER_API + 'all');
  }
}
